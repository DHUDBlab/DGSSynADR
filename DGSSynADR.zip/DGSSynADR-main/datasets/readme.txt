There are some main data about drugs, cell line and protein
