THis is some configrations about parameter
